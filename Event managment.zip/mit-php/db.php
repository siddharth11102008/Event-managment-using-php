<?php
$conn = mysqli_connect("localhost", "root", "", "event_managment_db");

if(!$conn){
    die("Connection Failed: " . mysqli_connect_error());
}
?>