<?php
session_start();
if(!isset($_SESSION['admin'])){
    header("location:index.php");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Panel</title>
    <style>
        body{
            margin:0;
            font-family:Arial;
            background:#f4f4f4;
        }

        .navbar{
            background:#2c3e50;
            padding:15px;
            display:flex;
            justify-content:space-between;
            align-items:center;
        }

        .navbar .logo{
            color:white;
            font-size:20px;
            font-weight:bold;
        }

        .navbar a{
            color:white;
            margin:0 10px;
            text-decoration:none;
        }

        .navbar a:hover{
            text-decoration:underline;
        }

        .container{
            padding:20px;
        }
    </style>
</head>
<body>

<div class="navbar">
    <div class="logo">Admin Panel</div>
    <div>
        <a href="view_package.php">Packages</a>
        <a href="view_gallery.php">Gallery</a>
        <a href="view_booking.php">Bookings</a>
        <a href="view_feedback.php">Feedback</a>
        <a href="logout.php">Logout</a>
    </div>
</div>

<div class="container"> 