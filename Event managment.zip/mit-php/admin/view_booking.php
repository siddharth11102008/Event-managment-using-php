<?php include('header.php'); include('../db.php');

$q = mysqli_query($conn, "
SELECT bookings.*, users.name, packages.title 
FROM bookings
JOIN users ON bookings.user_id = users.user_id
JOIN packages ON bookings.package_id = packages.package_id
");
?>

<h2>All Bookings</h2>

<table>
<tr>
    <th>User</th>
    <th>Package</th>
    <th>Date</th>
    <th>Guests</th>
    <th>Status</th>
    <th>Action</th>
</tr>

<?php while($r = mysqli_fetch_assoc($q)){ ?>
<tr>
    <td><?php echo $r['name']; ?></td>
    <td><?php echo $r['title']; ?></td>
    <td><?php echo $r['event_date']; ?></td>
    <td><?php echo $r['guests']; ?></td>
    <td>
        <span class="status <?php echo strtolower($r['status']); ?>">
            <?php echo $r['status']; ?>
        </span>
    </td>
    <td>
        <a href="update_status.php?id=<?php echo $r['booking_id']; ?>&status=Approved" class="approve">Approve</a>
        <a href="update_status.php?id=<?php echo $r['booking_id']; ?>&status=Rejected" class="reject">Reject</a>
    </td>
</tr>
<?php } ?>

</table>

<style>
table{
    width:100%;
    border-collapse:collapse;
    background:white;
}
th, td{
    padding:10px;
    text-align:center;
    border:1px solid #ddd;
}
th{
    background:#2c3e50;
    color:white;
}

.status{
    padding:5px 10px;
    border-radius:5px;
    color:white;
}

.status.pending{background:orange;}
.status.approved{background:green;}
.status.rejected{background:red;}

.approve{
    color:green;
    text-decoration:none;
    margin-right:10px;
}

.reject{
    color:red;
    text-decoration:none;
}
</style>

<?php include('footer.php'); ?>