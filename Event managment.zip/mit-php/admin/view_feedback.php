<?php include('header.php'); include('../db.php');

$q = mysqli_query($conn,"
SELECT feedback.*, users.name 
FROM feedback
JOIN users ON feedback.user_id = users.user_id
");
?>

<h2>User Feedback</h2>

<div class="grid">

<?php while($r = mysqli_fetch_assoc($q)){ ?>

<div class="card">

    <h3><?php echo $r['name']; ?></h3>

    <div class="stars">
        <?php 
        for($i=1;$i<=5;$i++){
            echo ($i <= $r['rating']) ? "⭐" : "☆";
        }
        ?>
    </div>

    <p><?php echo $r['message']; ?></p>

</div>

<?php } ?>

</div>

<style>

.grid{
    display:flex;
    flex-wrap:wrap;
    gap:20px;
}

.card{
    width:250px;
    background:white;
    padding:15px;
    border-radius:10px;
    box-shadow:0 5px 15px rgba(0,0,0,0.1);
}

.card h3{
    margin-bottom:10px;
}

</style>

<?php include('footer.php'); ?>