<?php include('header.php'); include('../db.php');

if(isset($_POST['add'])){
    $title = $_POST['title'];
    $desc = $_POST['description'];
    $price = $_POST['price'];

    $img = $_FILES['image']['name'];
    $tmp = $_FILES['image']['tmp_name'];

    move_uploaded_file($tmp, "../uploads/".$img);

    mysqli_query($conn, "INSERT INTO packages(title,description,price,image) 
    VALUES('$title','$desc','$price','$img')");
}
?>

<h2>Add Package</h2>

<form method="post" enctype="multipart/form-data">
    <input type="text" name="title" placeholder="Title" required><br><br>
    <textarea name="description" placeholder="Description"></textarea><br><br>
    <input type="number" name="price" placeholder="Price" required><br><br>
    <input type="file" name="image" required><br><br>
    <button name="add">Add Package</button>
</form>

<?php include('footer.php'); ?>