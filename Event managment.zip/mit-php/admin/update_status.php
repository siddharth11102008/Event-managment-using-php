<?php
include('../db.php');

$id = $_GET['id'];
$status = $_GET['status'];

mysqli_query($conn, "UPDATE bookings SET status='$status' WHERE booking_id='$id'");

header("location:view_booking.php");
?>