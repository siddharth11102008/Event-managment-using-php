<?php
include('../db.php');

$id = $_GET['id'];

mysqli_query($conn, "DELETE FROM gallery WHERE gallery_id='$id'");

header("location:view_gallery.php");
?>