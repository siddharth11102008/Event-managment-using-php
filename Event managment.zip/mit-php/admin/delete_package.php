<?php
include('../db.php');

$id = $_GET['id'];

mysqli_query($conn, "DELETE FROM packages WHERE package_id='$id'");

header("location:view_package.php");
?>