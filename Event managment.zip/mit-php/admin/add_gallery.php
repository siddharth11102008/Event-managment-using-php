<?php include('header.php'); include('../db.php');

if(isset($_POST['add'])){
    $title = $_POST['title'];

    $img = $_FILES['image']['name'];
    $tmp = $_FILES['image']['tmp_name'];

    $path = "../uploads/".$img;

    if(move_uploaded_file($tmp, $path)){
        mysqli_query($conn, "INSERT INTO gallery(title,image) VALUES('$title','$img')");
        echo "<p style='color:green;'>Image Uploaded Successfully</p>";
        header("location:view_gallery.php");
    } else {
        echo "<p style='color:red;'>Upload Failed</p>";
    }
}
?>

<h2>Add Gallery</h2>

<form method="post" enctype="multipart/form-data" class="form-box">
    <input type="text" name="title" placeholder="Image Title" required>
    <input type="file" name="image" required>
    <button name="add">Upload</button>
</form>