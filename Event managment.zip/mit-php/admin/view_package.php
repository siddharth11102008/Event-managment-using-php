<?php include('header.php'); include('../db.php');

$q = mysqli_query($conn, "SELECT * FROM packages");
?>

<h2>All Packages</h2>

<a href="add_package.php">+ Add New</a><br><br>

<table border="1" cellpadding="10">
<tr>
    <th>Title</th>
    <th>Price</th>
    <th>Image</th>
    <th>Action</th>
</tr>

<?php while($r = mysqli_fetch_assoc($q)){ ?>
<tr>
    <td><?php echo $r['title']; ?></td>
    <td><?php echo $r['price']; ?></td>
    <td>
    <img src="../uploads/<?php echo $r['image']; ?>" width="100" height="80" style="object-fit:cover;">
</td>
    <td>
        <a href="edit_package.php?id=<?php echo $r['package_id']; ?>">Edit</a> |
        <a href="delete_package.php?id=<?php echo $r['package_id']; ?>">Delete</a>
    </td>
</tr>
<?php } ?>

</table>

<?php include('footer.php'); ?>