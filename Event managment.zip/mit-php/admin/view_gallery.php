<?php include('header.php'); include('../db.php');

$q = mysqli_query($conn, "SELECT * FROM gallery");
?>

<h2>Gallery List</h2>

<a href="add_gallery.php" class="btn">+ Add Image</a><br><br>

<div class="grid">
<?php while($r = mysqli_fetch_assoc($q)){ ?>
    <div class="card">
        <img src="../uploads/<?php echo $r['image']; ?>">
        <h4><?php echo $r['title']; ?></h4>
        <a href="delete_gallery.php?id=<?php echo $r['gallery_id']; ?>" class="delete">Delete</a>
    </div>
<?php } ?>
</div>

<style>
.btn{
    padding:10px;
    background:#27ae60;
    color:white;
    text-decoration:none;
}

.grid{
    display:flex;
    flex-wrap:wrap;
    gap:20px;
}

.card{
    width:200px;
    background:white;
    padding:10px;
    box-shadow:0 0 10px gray;
    text-align:center;
}

.card img{
    width:100%;
    height:150px;
    object-fit:cover;
}

.delete{
    display:inline-block;
    margin-top:10px;
    color:red;
    text-decoration:none;
}
</style>

<?php include('footer.php'); ?>