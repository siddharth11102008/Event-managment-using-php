<?php include('header.php'); include('../db.php');

$id = $_GET['id'];

$q = mysqli_query($conn, "SELECT * FROM packages WHERE package_id='$id'");
$r = mysqli_fetch_assoc($q);

if(isset($_POST['update'])){
    $title = $_POST['title'];
    $desc = $_POST['description'];
    $price = $_POST['price'];

    if($_FILES['image']['name'] != ""){
        $img = $_FILES['image']['name'];
        $tmp = $_FILES['image']['tmp_name'];
        move_uploaded_file($tmp, "../uploads/".$img);

        mysqli_query($conn, "UPDATE packages SET 
        title='$title', description='$desc', price='$price', image='$img'
        WHERE package_id='$id'");
    } else {
        mysqli_query($conn, "UPDATE packages SET 
        title='$title', description='$desc', price='$price'
        WHERE package_id='$id'");
    }

    header("location:view_package.php");
}
?>

<h2>Edit Package</h2>

<form method="post" enctype="multipart/form-data">
    <input type="text" name="title" value="<?php echo $r['title']; ?>"><br><br>
    <textarea name="description"><?php echo $r['description']; ?></textarea><br><br>
    <input type="number" name="price" value="<?php echo $r['price']; ?>"><br><br>
    
    <img src="uploads/<?php echo $r['image']; ?>" width="100"><br><br>
    
    <input type="file" name="image"><br><br>
    <button name="update">Update</button>
</form>

<?php include('footer.php'); ?>