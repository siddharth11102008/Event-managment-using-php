<!DOCTYPE html>
<html>
<head>
<title>Event Management System</title>

<style>

/* Reset */
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family: 'Arial', sans-serif;
}

/* Body */
body{
    background:#f0f4f8;
}

/* Header */
.header{
    background:#6c5ce7;
    color:white;
    text-align:center;
    padding:40px 20px;
}

.header h1{
    font-size:36px;
}

.header p{
    margin-top:10px;
    font-size:16px;
}

/* Container */
.container{
    width:90%;
    max-width:1000px;
    margin:30px auto;
}

/* Buttons */
.buttons{
    display:flex;
    justify-content:center;
    gap:20px;
    margin-bottom:30px;
}

.btn{
    padding:15px 30px;
    font-size:16px;
    border:none;
    border-radius:8px;
    text-decoration:none;
    color:white;
    transition:0.3s;
}

/* Admin */
.admin{
    background:#e17055;
}
.admin:hover{
    background:#d35400;
}

/* User */
.user{
    background:#00b894;
}
.user:hover{
    background:#019875;
}

/* Card */
.card{
    background:white;
    padding:25px;
    border-radius:10px;
    box-shadow:0 5px 15px rgba(0,0,0,0.1);
    margin-bottom:20px;
}

/* Footer */
.footer{
    text-align:center;
    padding:15px;
    background:#2d3436;
    color:white;
    margin-top:40px;
}

</style>

</head>
<body>

<div class="header">
    <h1>🎉 Event Management System</h1>
    <p>Organize your events in a smart and simple way</p>
</div>

<div class="container">

<div class="buttons">
    <a href="admin/index.php" class="btn admin">Admin Panel</a>
    <a href="user/login.php" class="btn user">User Panel</a>
</div>

<div class="card">
    <h3>About This System</h3>
    <p>
    This Event Management System helps users to explore event packages and book services easily.
    Admin can manage packages, gallery, and bookings.
    </p>
</div>

<div class="card">
    <h3>Features</h3>
    <p>
    ✔ Easy Booking<br>
    ✔ Multiple Packages<br>
    ✔ Admin Dashboard<br>
    ✔ User Friendly Design<br>
    ✔ Fast & Simple System
    </p>
</div>

</div>

<div class="footer">
    © 2026 Event Management System | Developed by mitraj 🚀
</div>

</body>
</html>