<?php include('header.php'); include('../db.php');

$q = mysqli_query($conn, "SELECT * FROM gallery");
?>

<h2 class="title">Gallery</h2>

<div class="grid">

<?php while($r = mysqli_fetch_assoc($q)){ ?>

<div class="card">
    <img src="../uploads/<?php echo $r['image']; ?>">
    <p><?php echo $r['title']; ?></p>
</div>

<?php } ?>

</div>

<style>

/* Title */
.title{
    margin:20px;
    font-size:26px;
}

/* GRID (6 per row) */
.grid{
    display:grid;
    grid-template-columns: repeat(6, 1fr);
    gap:20px;
    padding:20px;
}

/* CARD */
.card{
    background:white;
    padding:10px;
    border-radius:12px;
    box-shadow:0 5px 15px rgba(0,0,0,0.1);
    text-align:center;
    transition:0.3s;
}

.card:hover{
    transform:translateY(-5px);
}

/* IMAGE */
.card img{
    width:100%;
    height:140px;
    object-fit:cover;
    border-radius:10px;
}

/* TEXT */
.card p{
    margin-top:8px;
    font-weight:bold;
}

/* RESPONSIVE */
@media (max-width:1200px){
    .grid{
        grid-template-columns: repeat(4, 1fr);
    }
}

@media (max-width:768px){
    .grid{
        grid-template-columns: repeat(2, 1fr);
    }
}

</style>

<?php include('footer.php'); ?>