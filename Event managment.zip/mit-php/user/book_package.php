<?php
session_start();
include('../db.php');

if(!isset($_SESSION['user'])){
    header("location:login.php");
}

$user_id = $_SESSION['user'];
$package_id = $_GET['id'];

if(isset($_POST['book'])){
    $date = $_POST['date'];
    $address = $_POST['address'];
    $guests = $_POST['guests'];
    $note = $_POST['note'];

    mysqli_query($conn, "INSERT INTO bookings(user_id,package_id,event_date,address,guests,note)
    VALUES('$user_id','$package_id','$date','$address','$guests','$note')");

    header("location:my_booking.php");
}
?>

<?php include('header.php'); ?>

<h2>Book Package</h2>

<form method="post" class="form-box">
    <input type="date" name="date" required>
    <textarea name="address" placeholder="Event Address" required></textarea>
    <input type="number" name="guests" placeholder="Number of Guests" required>
    <textarea name="note" placeholder="Additional Notes"></textarea>
    <button name="book">Book Now</button>
</form>

<style>
.form-box{
    width:350px;
    background:white;
    padding:20px;
    box-shadow:0 0 10px gray;
    border-radius:10px;
}

.form-box input, .form-box textarea, .form-box button{
    width:100%;
    padding:10px;
    margin:10px 0;
    border:1px solid #ccc;
    border-radius:5px;
}

.form-box button{
    background:#27ae60;
    color:white;
    border:none;
}
</style>

<?php include('footer.php'); ?>