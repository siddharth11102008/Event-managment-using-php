<?php
session_start();
include('../db.php');

if(!isset($_SESSION['user'])){
    header("location:login.php");
}

$user_id = $_SESSION['user'];
$msg = "";

if(isset($_POST['submit'])){
    $rating = $_POST['rating'];
    $message = $_POST['message'];

    mysqli_query($conn, "INSERT INTO feedback(user_id,rating,message)
    VALUES('$user_id','$rating','$message')");

    $msg = "Thanks for your feedback!";
}
?>

<?php include('header.php'); ?>

<div class="container">

    <h2>Share Your Experience</h2>
    <p class="sub">We value your feedback</p>

    <?php if($msg) echo "<p class='success'>$msg</p>"; ?>

    <form method="post" class="card">

        <!-- Stars -->
        <div class="stars">
            <?php for($i=5;$i>=1;$i--){ ?>
                <input type="radio" name="rating" id="star<?php echo $i; ?>" value="<?php echo $i; ?>" required>
                <label for="star<?php echo $i; ?>">★</label>
            <?php } ?>
        </div>

        <!-- Text -->
        <textarea name="message" placeholder="Write your feedback..." required></textarea>

        <button name="submit">Submit</button>

    </form>

</div>

<style>

.container{
    display:flex;
    flex-direction:column;
    align-items:center;
    padding:40px;
}

h2{
    font-size:28px;
}

.sub{
    color:gray;
    margin-bottom:20px;
}

.success{
    color:green;
}

/* Card */
.card{
    width:400px;
    background:white;
    padding:25px;
    border-radius:12px;
    box-shadow:0 10px 25px rgba(0,0,0,0.1);
}

/* Stars */
.stars{
    display:flex;
    flex-direction:row-reverse;
    justify-content:center;
    margin-bottom:20px;
}

.stars input{
    display:none;
}

.stars label{
    font-size:32px;
    color:#ddd;
    cursor:pointer;
    transition:0.3s;
}

.stars label:hover,
.stars label:hover ~ label,
.stars input:checked ~ label{
    color:#f1c40f;
}

/* Textarea */
textarea{
    width:100%;
    height:100px;
    padding:10px;
    border-radius:8px;
    border:1px solid #ccc;
    margin-bottom:15px;
}

/* Button */
button{
    width:100%;
    padding:10px;
    border:none;
    border-radius:8px;
    background:#2c3e50;
    color:white;
    font-size:16px;
    cursor:pointer;
}

button:hover{
    background:#34495e;
}

</style>

<?php include('footer.php'); ?>