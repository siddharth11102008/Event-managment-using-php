<?php
session_start();
include('../db.php');

if(isset($_POST['login'])){
    $email = $_POST['email'];
    $password = $_POST['password'];

    $q = mysqli_query($conn, "SELECT * FROM users WHERE email='$email' AND password='$password'");

    if(mysqli_num_rows($q) > 0){
        $r = mysqli_fetch_assoc($q);
        $_SESSION['user'] = $r['user_id'];
        header("location:index.php");
    } else {
        $error = "Invalid Email or Password";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>User Login</title>
    <style>
        body{
            margin:0;
            font-family:Arial;
            background:linear-gradient(to right, #36d1dc, #5b86e5);
        }

        .box{
            width:350px;
            margin:100px auto;
            background:white;
            padding:30px;
            border-radius:10px;
            box-shadow:0 0 15px rgba(0,0,0,0.3);
            text-align:center;
        }

        input{
            width:100%;
            padding:10px;
            margin:10px 0;
            border:1px solid #ccc;
            border-radius:5px;
        }

        button{
            width:100%;
            padding:10px;
            background:#5b86e5;
            color:white;
            border:none;
            border-radius:5px;
            cursor:pointer;
        }

        button:hover{background:#4a74d1;}

        .error{color:red;}
        a{text-decoration:none;color:#5b86e5;}
    </style>
</head>
<body>

<div class="box">
    <h2>User Login</h2>

    <?php if(isset($error)) echo "<p class='error'>$error</p>"; ?>

    <form method="post">
        <input type="email" name="email" placeholder="Enter Email" required>
        <input type="password" name="password" placeholder="Enter Password" required>
        <button name="login">Login</button>
    </form>

    <p>Don't have account? <a href="register.php">Register</a></p>
</div>

</body>
</html>