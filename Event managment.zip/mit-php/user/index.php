<?php include('header.php'); ?>

<div class="hero">
    <h1>Welcome to Event Management System</h1>
    <p>Plan your events easily and quickly</p>
    <a href="view_package.php" class="btn">View Packages</a>
</div>

<div class="section">
    <h2>Our Services</h2>

    <div class="cards">
        <div class="card">
            <h3>Wedding</h3>
            <p>Complete wedding planning & decoration</p>
        </div>

        <div class="card">
            <h3>Birthday</h3>
            <p>Fun birthday party setup</p>
        </div>

        <div class="card">
            <h3>Corporate</h3>
            <p>Professional corporate events</p>
        </div>
    </div>
</div>

<style>
.hero{
    height:350px;
    background:linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)),
    url('https://images.unsplash.com/photo-1511795409834-ef04bbd61622');
    background-size:cover;
    color:white;
    display:flex;
    justify-content:center;
    align-items:center;
    flex-direction:column;
}

.hero h1{font-size:35px;}

.btn{
    padding:10px 20px;
    background:#e67e22;
    color:white;
    text-decoration:none;
    margin-top:10px;
    border-radius:5px;
}

.section{
    text-align:center;
    padding:40px;
}

.cards{
    display:flex;
    justify-content:center;
    gap:20px;
}

.card{
    background:white;
    padding:20px;
    width:250px;
    box-shadow:0 0 10px gray;
}
</style>

<?php include('footer.php'); ?>