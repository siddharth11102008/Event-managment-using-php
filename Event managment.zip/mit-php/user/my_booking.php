<?php
session_start();
include('../db.php');

if(!isset($_SESSION['user'])){
    header("location:login.php");
}

$user_id = $_SESSION['user'];

$q = mysqli_query($conn, "
SELECT bookings.*, packages.title 
FROM bookings
JOIN packages ON bookings.package_id = packages.package_id
WHERE bookings.user_id='$user_id'
");
?>

<?php include('header.php'); ?>

<h2>My Bookings</h2>

<table>
<tr>
    <th>Package</th>
    <th>Date</th>
    <th>Guests</th>
    <th>Status</th>
</tr>

<?php while($r = mysqli_fetch_assoc($q)){ ?>
<tr>
    <td><?php echo $r['title']; ?></td>
    <td><?php echo $r['event_date']; ?></td>
    <td><?php echo $r['guests']; ?></td>
    <td>
        <span class="status <?php echo strtolower($r['status']); ?>">
            <?php echo $r['status']; ?>
        </span>
    </td>
</tr>
<?php } ?>

</table>

<style>
table{
    width:100%;
    border-collapse:collapse;
    background:white;
}

th, td{
    padding:10px;
    text-align:center;
    border:1px solid #ddd;
}

th{
    background:#2c3e50;
    color:white;
}

.status{
    padding:5px 10px;
    border-radius:5px;
    color:white;
}

.status.pending{background:orange;}
.status.approved{background:green;}
.status.rejected{background:red;}
</style>

<?php include('footer.php'); ?>