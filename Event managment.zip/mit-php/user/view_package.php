<?php include('header.php'); include('../db.php');

$q = mysqli_query($conn, "SELECT * FROM packages");
?>

<h2>Our Packages</h2>

<div class="grid">
<?php while($r = mysqli_fetch_assoc($q)){ ?>
    <div class="card">
         <img src="../uploads/<?php echo $r['image']; ?>" width="100" height="80" style="object-fit:cover;">
        <h3><?php echo $r['title']; ?></h3>
        <p>₹ <?php echo $r['price']; ?></p>
        <a href="package_details.php?id=<?php echo $r['package_id']; ?>" class="btn">View Details</a>
    </div>
<?php } ?>
</div>

<style>
.grid{
    display:flex;
    flex-wrap:wrap;
    gap:20px;
}

.card{
    width:250px;
    background:white;
    padding:15px;
    box-shadow:0 0 10px gray;
    text-align:center;
    border-radius:10px;
}

.card img{
    width:100%;
    height:180px;
    object-fit:cover;
    border-radius:10px;
}

.btn{
    display:inline-block;
    margin-top:10px;
    padding:8px 15px;
    background:#27ae60;
    color:white;
    text-decoration:none;
    border-radius:5px;
}
</style>

<?php include('footer.php'); ?>