<?php include('header.php'); include('../db.php');

$id = $_GET['id'];

$q = mysqli_query($conn, "SELECT * FROM packages WHERE package_id='$id'");
$r = mysqli_fetch_assoc($q);
?>

<h2>Package Details</h2>

<div class="details">
    <img src="<?php echo $r['image']; ?>" width="100" height="80" style="object-fit:cover;">

    <div class="info">
        <h3><?php echo $r['title']; ?></h3>
        <p><?php echo $r['description']; ?></p>
        <h4>Price: ₹ <?php echo $r['price']; ?></h4>
        

        <a href="book_package.php?id=<?php echo $r['package_id']; ?>" class="btn">Book Now</a>
    </div>
</div>

<style>
.details{
    display:flex;
    gap:30px;
    background:white;
    padding:20px;
    box-shadow:0 0 10px gray;
    border-radius:10px;
}

.details img{
    width:350px;
    height:250px;
    object-fit:cover;
    border-radius:10px;
}

.info{
    max-width:500px;
}

.btn{
    display:inline-block;
    padding:10px 20px;
    background:#e67e22;
    color:white;
    text-decoration:none;
    border-radius:5px;
    margin-top:10px;
}
</style>

<?php include('footer.php'); ?>