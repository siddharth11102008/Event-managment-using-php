</div>

<div style="background:#2c3e50;color:white;text-align:center;padding:12px;">
    <p>© 2026 Event Management System</p>
</div>

</body>
</html>