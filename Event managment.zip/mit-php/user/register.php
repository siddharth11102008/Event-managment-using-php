<?php
include('../db.php');

$msg = "";

if(isset($_POST['register'])){
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);

    // Check email already exists
    $check = mysqli_query($conn, "SELECT * FROM users WHERE email='$email'");

    if(mysqli_num_rows($check) > 0){
        $msg = "Email already registered!";
    } else {

        // Insert data
        if(mysqli_query($conn, "INSERT INTO users(name,email,password,phone)
        VALUES('$name','$email','$password','$phone')")){
            
            header("location:login.php");
            exit();
        } else {
            $msg = "Error: " . mysqli_error($conn);
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>User Register</title>
    <style>
        body{
            margin:0;
            font-family:Arial;
            background:linear-gradient(to right, #ff7e5f, #feb47b);
        }

        .box{
            width:350px;
            margin:80px auto;
            background:white;
            padding:30px;
            border-radius:10px;
            box-shadow:0 0 15px rgba(0,0,0,0.3);
            text-align:center;
        }

        input{
            width:100%;
            padding:10px;
            margin:10px 0;
            border:1px solid #ccc;
            border-radius:5px;
        }

        button{
            width:100%;
            padding:10px;
            background:#ff7e5f;
            color:white;
            border:none;
            border-radius:5px;
            cursor:pointer;
        }

        button:hover{background:#e96a50;}

        .msg{
            color:red;
        }

        a{text-decoration:none;color:#ff7e5f;}
    </style>
</head>
<body>

<div class="box">
    <h2>User Registration</h2>

    <?php if($msg != "") echo "<p class='msg'>$msg</p>"; ?>

    <form method="post">
        <input type="text" name="name" placeholder="Full Name" required>
        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Password" required>
        <input type="text" name="phone" placeholder="Phone Number" required>
        <button name="register">Register</button>
    </form>

    <p>Already have account? <a href="login.php">Login</a></p>
</div>

</body>
</html>